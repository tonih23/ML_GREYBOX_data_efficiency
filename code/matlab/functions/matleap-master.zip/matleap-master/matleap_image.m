function i=matleap_image
% MATLEAP_FRAME Get a frame from the leap motion controller
i=matleap(2);
